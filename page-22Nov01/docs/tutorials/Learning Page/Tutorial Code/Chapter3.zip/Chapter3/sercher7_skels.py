def main(*args):
    '''Main entry point for the application.'''
    global root
    root = tk.Tk()
    root.protocol('WM_DELETE_WINDOW', root.destroy)
    # Creates a toplevel widget.
    global _top1, _w1
    _top1 = root
    _w1 = searcher.searcher(_top1)
    root.mainloop()


def OnBtnExit(*args):
    print('searcher_support.OnBtnExit')
    for arg in args:
        print('another arg:', arg)
    sys.stdout.flush()


def OnBtnGo(*args):
    print('searcher_support.OnBtnGo')
    for arg in args:
        print('another arg:', arg)
    sys.stdout.flush()


def OnBtnSearchPath(*args):
    print('searcher_support.OnBtnSearchPath')
    for arg in args:
        print('another arg:', arg)
    sys.stdout.flush()


def OnTreeviewClick(*args):
    print('searcher_support.OnTreeviewClick')
    for arg in args:
        print('another arg:', arg)
    sys.stdout.flush()


