Chapter 1 - Getting Started 
    Chapter One focuses on getting to know Page and the first glimpses of using Event Oriented programming. Subjects covered are the Page program interface, various windows, the methodology of creating a user interface, learning the three types of files created by Page and binding a control to an event, in this case a mouse click.
