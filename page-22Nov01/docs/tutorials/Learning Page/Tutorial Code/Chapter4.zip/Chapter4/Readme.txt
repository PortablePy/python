Chapter 4 - NASAStills
    Chapter Four shows how to use the Internet to show images in a Label widget.  Other topics include how to use the .after methods of the root window as a timer.

