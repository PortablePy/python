Chapter 5 - Multiple Forms and Menus
Chapter 5 completes the tutorial with how to use multiple forms (Toplevel windows) and how to create menus for your applications.
