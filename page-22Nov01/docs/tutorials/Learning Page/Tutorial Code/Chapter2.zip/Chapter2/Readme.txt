Chapter 2 - Moving On
    Chapter Two introduces Frame widgets, Static Text widgets (labels), Single line entry widgets (text boxes), Check buttons and Radio Buttons. Explicit information on placement of the various widgets, setting the width and height, setting the Alias and various other attributes for the various widgets including the Toplevel widget.

