This is a demo on how to use PAGE and the Plotext Python library together.  To be able to run this demo, you need to install the Plotext Python library version 4.1.3 or greater from https://github.com/piccolomo/plotext.

The idea is to create a label to display a plot.  The plot is sent to a Label widget as text.  You can use the textvar attribute of the label for this.

The biggest hurdle is determining the width/height of the label.  The Plotext author created a Tkinter example which uses a plotsize of 365 by 990 pixels.  This is a ratio of 4.05 to 1.  I used a smaller size of 160 x 35, which is the same ratio.  By using a 8 point monospace font, this fits very well in the label on my form which is 1019 x 511 pixels.  


