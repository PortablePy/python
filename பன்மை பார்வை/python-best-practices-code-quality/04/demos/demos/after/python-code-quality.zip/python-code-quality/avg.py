def average(a: int, b: int, c: int) -> float:
    return (a + b + c) / 3


print(average(1, 5, 7))