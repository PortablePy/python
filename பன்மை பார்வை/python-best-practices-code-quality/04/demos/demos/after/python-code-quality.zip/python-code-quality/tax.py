def vat(price: int) -> int:
    return round(price / 21) * 100

