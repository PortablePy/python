.. Pluralsight Demo documentation master file, created by
   sphinx-quickstart on Sat Apr 20 23:34:43 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Welcome to Pluralsight Demo's documentation!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This project serves mainly as an example project for this video course,
which I made for `Pluralsight <http://www.pluralsight>`_

This is a subtitle
------------------

We can include code examples in our page like this::

    import something
    x = something.else(a, b)
    print(c)


Subject of this demo
--------------------

We will discuss::

- Sphinx
- reStructuredText
- Generating documentation from code
- and more...


.. include:: modules.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
