gamedemo package
================

.. automodule:: gamedemo
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

gamedemo.game module
--------------------

.. automodule:: gamedemo.game
    :members:
    :undoc-members:
    :show-inheritance:

gamedemo.player module
----------------------

.. automodule:: gamedemo.player
    :members:
    :undoc-members:
    :show-inheritance:

gamedemo.weapons module
-----------------------

.. automodule:: gamedemo.weapons
    :members:
    :undoc-members:
    :show-inheritance:


